package com.sh.api.eshop.shopify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopifyApplicationTests {

	@Test
	void contextLoads() {
	}

}