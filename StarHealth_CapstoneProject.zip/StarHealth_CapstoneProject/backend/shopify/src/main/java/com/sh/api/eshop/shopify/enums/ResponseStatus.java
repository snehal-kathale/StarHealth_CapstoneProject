package com.sh.api.eshop.shopify.enums;

public enum ResponseStatus
{
    success,
    error
}
