package com.sh.api.eshop.shopify.utils;

public class Helper {
    public static boolean notNull(Object obj){
        return obj != null;
    }
}
