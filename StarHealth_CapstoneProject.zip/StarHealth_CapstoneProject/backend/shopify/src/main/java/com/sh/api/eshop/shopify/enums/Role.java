package com.sh.api.eshop.shopify.enums;

public enum Role {
    user,
    manager,
    admin
}
