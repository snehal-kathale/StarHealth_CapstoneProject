package com.sh.api.eshop.shopify.exception.util;

public class CustomException extends IllegalArgumentException {
    public CustomException(String msg) {
        super(msg);
    }
}
